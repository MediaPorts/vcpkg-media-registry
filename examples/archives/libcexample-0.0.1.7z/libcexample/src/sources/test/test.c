// self
#include <test/test.h>

// c
#include <stdio.h>



void test_func() {
    printf("func: %s, line: %d\n", __FUNCTION__, __LINE__);
}

