#pragma once


void my_test_func();


class MyTestClass {
public:
    MyTestClass();
    ~MyTestClass();

    void my_test_func();
};
